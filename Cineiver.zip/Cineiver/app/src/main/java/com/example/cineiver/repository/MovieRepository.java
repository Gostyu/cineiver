package com.example.cineiver.repository;

import android.util.Log;

import com.example.cineiver.model.Movie;
import com.example.cineiver.webservice.MovieApiClient;

import java.util.List;

public class MovieRepository {
    MovieApiClient mClient;
    List<Movie> movies;
    public MovieRepository(){
        //mClient=MovieApiClient.getMovieApiClientInstance();
        //movies = mClient.getPopularMovies();
    }
    public List<Movie> getMovies (){
        mClient=MovieApiClient.getMovieApiClientInstance();
        if(mClient==null){
            Log.d("MovieRp", "mClient is NULL");
        }else{
            Log.d("MovieRp", "mClient is NULL");
        }
      //  Log.d("MovieRP",MovieApiClient.getMovieApiClientInstance().getPopularMovies().toString());
        return null;
    }

}
