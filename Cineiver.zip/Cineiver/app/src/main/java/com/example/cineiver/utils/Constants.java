package com.example.cineiver.utils;

public class Constants {
    public static String API_KEY = "391f63013b803cbd3de2634d4d8619cf";
}
