package com.example.cineiver;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.example.cineiver.adapters.MovieListAdapter;
import com.example.cineiver.model.Movie;
import com.example.cineiver.repository.MovieRepository;
import com.example.cineiver.viewmodels.MovieListViewModel;
import com.example.cineiver.webservice.MovieApiClient;

import java.util.List;

public class MovieListActivity extends AppCompatActivity{
    RecyclerView recyclerView;
    MovieListAdapter movieListAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //MovieApiClient client= MovieApiClient.getMovieApiClientInstance();
        //client.getPopularMovies();
        MovieRepository repository = new MovieRepository();
        repository.getMovies();
        createRecyclerView();
        //MovieRepository repository = new MovieRepository();
       // repository.getMovies();
        createMovieViewModel();
    }
    void createRecyclerView(){
        recyclerView=findViewById(R.id.recyclerView);
        RecyclerView.LayoutManager layoutManager= new LinearLayoutManager(getBaseContext());
        recyclerView.setLayoutManager(layoutManager);
        movieListAdapter = new MovieListAdapter(getBaseContext());
       // recyclerView.setAdapter(movieListAdapter);
        recyclerView.setVisibility(View.VISIBLE);
    }
    void createMovieViewModel(){
        MovieListViewModel movieListViewModel= new ViewModelProvider.Factory() {
            @NonNull
            @Override
            public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
                return (T) new MovieListViewModel();
            }
        }.create(MovieListViewModel.class);
    }

}