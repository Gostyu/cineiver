package com.example.cineiver.webservice;

import android.util.Log;

import com.example.cineiver.model.Movie;
import com.example.cineiver.model.PopularMoviesResponse;
import com.example.cineiver.utils.Constants;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MovieApiClient{
    private static MovieApiClient instance=null;
    private static MovieApiService client = null;
    private List<Movie> movies;
    private MovieApiClient(){
        //instance=getMovieApiClientInstance();
        //client=getMovieApiServiceInstance();
    }
    public static MovieApiClient getMovieApiClientInstance() {
        return instance==null? instance=new MovieApiClient(): instance;
    }

    public static MovieApiService getMovieApiServiceInstance() {
        return client==null? new Retrofit.Builder().baseUrl(MovieApiService.API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(MovieApiService.class) : client;
    }
   public List<Movie> getPopularMovies(){
        try {
            Call<PopularMoviesResponse> popularMoviesResponseCall =getMovieApiServiceInstance().listPopularMovies(Constants.API_KEY);
            popularMoviesResponseCall.enqueue(new Callback<PopularMoviesResponse>() {
                @Override
                public void onResponse(Call<PopularMoviesResponse> call, Response<PopularMoviesResponse> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            Log.i("MOVIEAPI", response.body().getResults().toString());
                            setMovies(response.body().getResults());
                        }
                    }
                }
                @Override
                public void onFailure(Call<PopularMoviesResponse> call, Throwable t) {
                    Log.d("POPULAR_MOVIES_ERROR",t.getMessage());
                }
            });
        } catch (Exception e){
            e.printStackTrace();
        }
        return getMovies();
    }

    private List<Movie> getMovies() {
        return movies;
    }

    private void setMovies(List<Movie> movies) {
        this.movies = movies;
    }
}
